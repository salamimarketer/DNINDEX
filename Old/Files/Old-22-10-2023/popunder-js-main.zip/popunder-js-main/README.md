# popunder-js
Open popunder by click of each open window

How to use: just add the code on your website

<script type="text/javascript" src="js/ads.js"></script>

inside the ads.js file you can add as many ad links as you want, just add and remember to press a comma at the end of each line
